from database import create_connection
import pandas as pd
import matplotlib.pyplot as plt

def fetch_data():
    connection = create_connection()
    query = "SELECT * FROM sales_cc"
    df = pd.read_sql(query, connection)
    connection.close()
    return df.to_html(classes="table table-striped")


def fetch_group_by_data(column_name):
    connection = create_connection()
    query = f"select `{column_name}` , count(*) as count from sales_cc group by `{column_name}`"
    df = pd.read_sql(query, connection)
    connection.close()
    return df.to_html(classes="table table-striped")


def fetch_order_by_data(column_name):
    connection = create_connection()
    query = f"select * from sales_cc order by `{column_name}`"
    df = pd.read_sql(query, connection)
    connection.close()
    return df.to_html(classes="table table-striped")


def fetch_top_5_data(column_name):
    connection = create_connection()
    query = f"select * from sales_cc  limit 5"
    df = pd.read_sql(query, connection)
    connection.close()
    return df.to_html(classes="table table-striped")

def fetch_pie_data(column_name):
    connection = create_connection()
    query = f"select `{column_name}` , count(*) as count from sales_cc group by `{column_name}` limit 5"
    df = pd.read_sql(query, connection)
    connection.close()
    plt.figure(figsize=(10, 6))
    plt.pie(df['count'], labels=df[column_name], autopct='%1.1f%%', startangle=140)
    plt.axis('equal')  
    plt.savefig('static/pie_chart.png')
    plt.close()                         







