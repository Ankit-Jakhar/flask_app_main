import mysql.connector

def create_connection():
    connection = mysql.connector.connect(
        host='localhost',
        user='root',
        password='anilchanda',
        database='flask_db',
        port = 3306
    )
    return connection