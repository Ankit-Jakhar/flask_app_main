Step-1 -> Create a virtual environment using this command

    python -m venv flaskenv

Step-2 -> Activate the virtual environment using this command

    flaskenv\Scripts\activate

Step-3 -> Create a [.gitignore](.gitignore) file that ignore my virtual environment for my github

Step-4 -> Create a [requirements.txt](requirements.txt) for library that we needed in this application
Run the requirements.txt file using this command
    
    pip install -r requirements.txt

Step.5 -> Create a [database.py](database.py) that connect mysql with python

Step-6 -> Create two directory(folder)
1. templates -> that hold all the html pages
2. static -> that hold the all file that we need for redirecting using path like image

step-7 -> Create a flask file  [app.py](app.py) that hold all route

step-8 -> Create a [fetch.py](fetch.py) file that hold all function or query that use in this application