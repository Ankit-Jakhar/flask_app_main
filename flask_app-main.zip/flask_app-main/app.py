from flask import Flask, render_template
from database import create_connection
from fetch import fetch_data, fetch_group_by_data,fetch_order_by_data,fetch_top_5_data,fetch_pie_data

app = Flask(__name__)

@app.route('/')
@app.route('/fetch')
def fetch():
    table_html = fetch_data()
    return render_template('index.html', table=table_html)

@app.route('/group/<column_name>')
def fetch_group(column_name):
    table_html = fetch_group_by_data(column_name)
    return render_template('index.html', table=table_html)

@app.route('/order/<column_name>')
def fetch_order(column_name):
    table_html = fetch_order_by_data(column_name)
    return render_template('index.html', table=table_html)

@app.route('/top5/<column_name>')
def fetch_top5(column_name):
    table_html = fetch_top_5_data(column_name)
    return render_template('index.html', table=table_html)

@app.route('/pie/<column_name>')
def fetch_pie(column_name):
    fetch_pie_data(column_name)
    return render_template('image.html')
           
@app.route("/button")
def buttton():
    return render_template("button.html")

if __name__ == '__main__':
    app.run(debug=True)